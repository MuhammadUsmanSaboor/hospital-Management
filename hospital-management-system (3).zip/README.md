# Hospital Management System

A comprehensive hospital management system built with Next.js.

## Getting Started

1. Clone the repository
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Run the development server:
   \`\`\`bash
   npm run dev
   \`\`\`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Adding Your Logo

To add your hospital logo:

1. Place your logo file in the `public` directory (e.g., `public/logo.png`)
2. Update the `src` attribute in the `Image` component in `components/header.tsx`:

\`\`\`tsx
<Image
  src="/logo.png" // Update this path to your logo file
  alt="Hospital Logo"
  width={32}
  height={32}
  className="rounded-md"
/>
\`\`\`

## Features

- Dashboard with key metrics
- Patient management
- Doctor management
- Appointment scheduling
- Department management
- Room and ward management
- Medication tracking
- Billing and invoicing
- Reporting

## Connecting to Your Backend

This frontend is designed to connect to your backend API. To connect to your actual backend:

1. Update the API endpoints in the `lib/data-service.ts` file
2. Replace the mock data with actual API calls

## Technology Stack

- Next.js 14
- React
- TypeScript
- Tailwind CSS
- shadcn/ui components
