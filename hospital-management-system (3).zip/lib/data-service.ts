import { fetchData, postData, updateData, deleteData } from "./db"

// Update the API_ENDPOINTS object to match your backend's API structure
const API_ENDPOINTS = {
  patients: "api/patients",
  doctors: "api/doctors",
  appointments: "api/appointments",
  departments: "api/departments",
  rooms: "api/rooms",
  medications: "api/medications",
  billing: "api/billing",
}

// Mock data for billing
const billing = [
  {
    id: "B001",
    patientId: "P001",
    patientName: "John Smith",
    invoiceDate: "2023-04-10",
    dueDate: "2023-04-25",
    totalAmount: "1500",
    paymentStatus: "Paid",
    paymentMethod: "Credit Card",
    paymentDate: "2023-04-15",
  },
  {
    id: "B002",
    patientId: "P002",
    patientName: "Sarah Johnson",
    invoiceDate: "2023-04-12",
    dueDate: "2023-04-27",
    totalAmount: "800",
    paymentStatus: "Pending",
    paymentMethod: "",
    paymentDate: "",
  },
  {
    id: "B003",
    patientId: "P003",
    patientName: "Michael Brown",
    invoiceDate: "2023-04-05",
    dueDate: "2023-04-20",
    totalAmount: "2200",
    paymentStatus: "Overdue",
    paymentMethod: "",
    paymentDate: "",
  },
  {
    id: "B004",
    patientId: "P004",
    patientName: "Emily Davis",
    invoiceDate: "2023-04-08",
    dueDate: "2023-04-23",
    totalAmount: "350",
    paymentStatus: "Paid",
    paymentMethod: "Cash",
    paymentDate: "2023-04-08",
  },
  {
    id: "B005",
    patientId: "P005",
    patientName: "Robert Wilson",
    invoiceDate: "2023-04-14",
    dueDate: "2023-04-29",
    totalAmount: "1800",
    paymentStatus: "Pending",
    paymentMethod: "",
    paymentDate: "",
  },
]

// This is a mock data service that simulates API calls
// In a real application, you would replace these with actual API calls

// Mock data for patients
const patients = [
  {
    id: "P001",
    name: "John Smith",
    age: 45,
    gender: "Male",
    phone: "555-123-4567",
    email: "john.smith@example.com",
    address: "123 Main St, Anytown",
    status: "Admitted",
  },
  {
    id: "P002",
    name: "Sarah Johnson",
    age: 32,
    gender: "Female",
    phone: "555-234-5678",
    email: "sarah.johnson@example.com",
    address: "456 Oak Ave, Somewhere",
    status: "Discharged",
  },
  {
    id: "P003",
    name: "Michael Brown",
    age: 58,
    gender: "Male",
    phone: "555-345-6789",
    email: "michael.brown@example.com",
    address: "789 Pine Rd, Nowhere",
    status: "Admitted",
  },
  {
    id: "P004",
    name: "Emily Davis",
    age: 27,
    gender: "Female",
    phone: "555-456-7890",
    email: "emily.davis@example.com",
    address: "101 Elm St, Elsewhere",
    status: "Outpatient",
  },
  {
    id: "P005",
    name: "Robert Wilson",
    age: 63,
    gender: "Male",
    phone: "555-567-8901",
    email: "robert.wilson@example.com",
    address: "202 Maple Dr, Anywhere",
    status: "Admitted",
  },
]

// Mock data for doctors
const doctors = [
  {
    id: "D001",
    name: "Dr. James Wilson",
    specialization: "Cardiology",
    phone: "555-111-2222",
    email: "james.wilson@hospital.com",
    status: "Active",
  },
  {
    id: "D002",
    name: "Dr. Emily Johnson",
    specialization: "Neurology",
    phone: "555-222-3333",
    email: "emily.johnson@hospital.com",
    status: "Active",
  },
  {
    id: "D003",
    name: "Dr. Robert Smith",
    specialization: "Orthopedics",
    phone: "555-333-4444",
    email: "robert.smith@hospital.com",
    status: "On Leave",
  },
  {
    id: "D004",
    name: "Dr. Sarah Davis",
    specialization: "Pediatrics",
    phone: "555-444-5555",
    email: "sarah.davis@hospital.com",
    status: "Active",
  },
  {
    id: "D005",
    name: "Dr. Michael Brown",
    specialization: "Dermatology",
    phone: "555-555-6666",
    email: "michael.brown@hospital.com",
    status: "Active",
  },
]

// Mock data for appointments
const appointments = [
  {
    id: "A001",
    patientName: "John Smith",
    patientId: "P001",
    doctorName: "Dr. James Wilson",
    doctorId: "D001",
    date: "2023-04-15",
    time: "09:00 AM",
    department: "Cardiology",
    status: "Scheduled",
  },
  {
    id: "A002",
    patientName: "Sarah Johnson",
    patientId: "P002",
    doctorName: "Dr. Emily Johnson",
    doctorId: "D002",
    date: "2023-04-15",
    time: "10:30 AM",
    department: "Neurology",
    status: "Completed",
  },
  {
    id: "A003",
    patientName: "Michael Brown",
    patientId: "P003",
    doctorName: "Dr. Robert Smith",
    doctorId: "D003",
    date: "2023-04-16",
    time: "11:00 AM",
    department: "Orthopedics",
    status: "Scheduled",
  },
  {
    id: "A004",
    patientName: "Emily Davis",
    patientId: "P004",
    doctorName: "Dr. Sarah Davis",
    doctorId: "D004",
    date: "2023-04-16",
    time: "02:00 PM",
    department: "Pediatrics",
    status: "Cancelled",
  },
  {
    id: "A005",
    patientName: "Robert Wilson",
    patientId: "P005",
    doctorName: "Dr. Michael Brown",
    doctorId: "D005",
    date: "2023-04-17",
    time: "03:30 PM",
    department: "Dermatology",
    status: "Scheduled",
  },
]

// Mock data for departments
const departments = [
  {
    id: "DEP001",
    name: "Cardiology",
    headOfDepartment: "Dr. James Wilson",
    location: "Building A, Floor 2",
    contactNumber: "555-111-2222",
    email: "cardiology@hospital.com",
  },
  {
    id: "DEP002",
    name: "Neurology",
    headOfDepartment: "Dr. Emily Johnson",
    location: "Building B, Floor 3",
    contactNumber: "555-222-3333",
    email: "neurology@hospital.com",
  },
  {
    id: "DEP003",
    name: "Orthopedics",
    headOfDepartment: "Dr. Robert Smith",
    location: "Building A, Floor 1",
    contactNumber: "555-333-4444",
    email: "orthopedics@hospital.com",
  },
  {
    id: "DEP004",
    name: "Pediatrics",
    headOfDepartment: "Dr. Sarah Davis",
    location: "Building C, Floor 2",
    contactNumber: "555-444-5555",
    email: "pediatrics@hospital.com",
  },
  {
    id: "DEP005",
    name: "Dermatology",
    headOfDepartment: "Dr. Michael Brown",
    location: "Building B, Floor 1",
    contactNumber: "555-555-6666",
    email: "dermatology@hospital.com",
  },
]

// Mock data for rooms
const rooms = [
  {
    id: "R001",
    roomNumber: "A-101",
    type: "Private Room",
    floor: "1",
    department: "DEP001",
    capacity: "1",
    status: "Occupied",
    rate: "500",
  },
  {
    id: "R002",
    roomNumber: "A-102",
    type: "Private Room",
    floor: "1",
    department: "DEP001",
    capacity: "1",
    status: "Available",
    rate: "500",
  },
  {
    id: "R003",
    roomNumber: "B-201",
    type: "Semi-Private Room",
    floor: "2",
    department: "DEP002",
    capacity: "2",
    status: "Occupied",
    rate: "300",
  },
  {
    id: "R004",
    roomNumber: "C-301",
    type: "ICU",
    floor: "3",
    department: "DEP003",
    capacity: "1",
    status: "Available",
    rate: "1000",
  },
  {
    id: "R005",
    roomNumber: "D-401",
    type: "General Ward",
    floor: "4",
    department: "DEP004",
    capacity: "4",
    status: "Occupied",
    rate: "200",
  },
]

// Mock data for medications
const medications = [
  {
    id: "M001",
    name: "Aspirin",
    category: "Analgesic",
    dosage: "500mg",
    manufacturer: "Bayer",
    stockQuantity: "1000",
    unitPrice: "0.5",
  },
  {
    id: "M002",
    name: "Amoxicillin",
    category: "Antibiotic",
    dosage: "250mg",
    manufacturer: "Pfizer",
    stockQuantity: "500",
    unitPrice: "1.2",
  },
  {
    id: "M003",
    name: "Lisinopril",
    category: "Antihypertensive",
    dosage: "10mg",
    manufacturer: "AstraZeneca",
    stockQuantity: "300",
    unitPrice: "2.5",
  },
  {
    id: "M004",
    name: "Metformin",
    category: "Antidiabetic",
    dosage: "500mg",
    manufacturer: "Merck",
    stockQuantity: "400",
    unitPrice: "1.8",
  },
  {
    id: "M005",
    name: "Atorvastatin",
    category: "Statin",
    dosage: "20mg",
    manufacturer: "Pfizer",
    stockQuantity: "600",
    unitPrice: "3.2",
  },
]

// Data service functions
export const dataService = {
  // Patients
  getPatients: () => fetchData(API_ENDPOINTS.patients),
  getPatientById: (id: string) => fetchData(`${API_ENDPOINTS.patients}/${id}`),
  createPatient: (patient: any) => postData(API_ENDPOINTS.patients, patient),
  updatePatient: (id: string, patient: any) => updateData(API_ENDPOINTS.patients, id, patient),
  deletePatient: (id: string) => deleteData(API_ENDPOINTS.patients, id),

  // Doctors
  getDoctors: () => fetchData(API_ENDPOINTS.doctors),
  getDoctorById: (id: string) => fetchData(`${API_ENDPOINTS.doctors}/${id}`),
  createDoctor: (doctor: any) => postData(API_ENDPOINTS.doctors, doctor),
  updateDoctor: (id: string, doctor: any) => updateData(API_ENDPOINTS.doctors, id, doctor),
  deleteDoctor: (id: string) => deleteData(API_ENDPOINTS.doctors, id),

  // Appointments
  getAppointments: () => fetchData(API_ENDPOINTS.appointments),
  getAppointmentById: (id: string) => fetchData(`${API_ENDPOINTS.appointments}/${id}`),
  createAppointment: (appointment: any) => postData(API_ENDPOINTS.appointments, appointment),
  updateAppointment: (id: string, appointment: any) => updateData(API_ENDPOINTS.appointments, id, appointment),
  deleteAppointment: (id: string) => deleteData(API_ENDPOINTS.appointments, id),

  // Departments
  getDepartments: () => fetchData(API_ENDPOINTS.departments),
  getDepartmentById: (id: string) => fetchData(`${API_ENDPOINTS.departments}/${id}`),
  createDepartment: (department: any) => postData(API_ENDPOINTS.departments, department),
  updateDepartment: (id: string, department: any) => updateData(API_ENDPOINTS.departments, id, department),
  deleteDepartment: (id: string) => deleteData(API_ENDPOINTS.departments, id),

  // Rooms
  getRooms: () => fetchData(API_ENDPOINTS.rooms),
  getRoomById: (id: string) => fetchData(`${API_ENDPOINTS.rooms}/${id}`),
  createRoom: (room: any) => postData(API_ENDPOINTS.rooms, room),
  updateRoom: (id: string, room: any) => updateData(API_ENDPOINTS.rooms, id, room),
  deleteRoom: (id: string) => deleteData(API_ENDPOINTS.rooms, id),

  // Medications
  getMedications: () => fetchData(API_ENDPOINTS.medications),
  getMedicationById: (id: string) => fetchData(`${API_ENDPOINTS.medications}/${id}`),
  createMedication: (medication: any) => postData(API_ENDPOINTS.medications, medication),
  updateMedication: (id: string, medication: any) => updateData(API_ENDPOINTS.medications, id, medication),
  deleteMedication: (id: string) => deleteData(API_ENDPOINTS.medications, id),

  // Billing
  getBilling: () => fetchData(API_ENDPOINTS.billing),
  getBillingById: (id: string) => fetchData(`${API_ENDPOINTS.billing}/${id}`),
  createBilling: (bill: any) => postData(API_ENDPOINTS.billing, bill),
  updateBilling: (id: string, bill: any) => updateData(API_ENDPOINTS.billing, id, bill),
  deleteBilling: (id: string) => deleteData(API_ENDPOINTS.billing, id),
}
