// This file handles API requests to your backend

// Use the environment variable for the API base URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001"

// Mock data for development (remove in production)
const patients = []
const doctors = []
const appointments = []
const departments = []
const rooms = []
const medications = []
const billing = []

// You might need to add authentication headers
const getHeaders = () => {
  const headers = {
    "Content-Type": "application/json",
    // Add any authentication headers here if your backend requires them
    // 'Authorization': `Bearer ${localStorage.getItem('token')}`,
  }
  return headers
}

// Update the fetchData function to better handle connection errors and provide fallback data

// Replace the entire fetchData function with this improved version:
export async function fetchData(endpoint: string) {
  try {
    // Log the fetch attempt for debugging
    console.log(`Attempting to fetch from: ${API_BASE_URL}/${endpoint}`)

    // Add a timeout to the fetch request
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

    const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
      headers: getHeaders(),
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`Error fetching data: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`Error fetching from ${endpoint}:`, error)

    // Return mock data when API is unavailable
    console.log(`Falling back to mock data for ${endpoint}`)

    // Return appropriate mock data based on the endpoint
    if (endpoint === "api/patients" || endpoint.startsWith("api/patients/")) {
      return endpoint.includes("/") ? patients[0] : patients
    }
    if (endpoint === "api/doctors" || endpoint.startsWith("api/doctors/")) {
      return endpoint.includes("/") ? doctors[0] : doctors
    }
    if (endpoint === "api/appointments" || endpoint.startsWith("api/appointments/")) {
      return endpoint.includes("/") ? appointments[0] : appointments
    }
    if (endpoint === "api/departments" || endpoint.startsWith("api/departments/")) {
      return endpoint.includes("/") ? departments[0] : departments
    }
    if (endpoint === "api/rooms" || endpoint.startsWith("api/rooms/")) {
      return endpoint.includes("/") ? rooms[0] : rooms
    }
    if (endpoint === "api/medications" || endpoint.startsWith("api/medications/")) {
      return endpoint.includes("/") ? medications[0] : medications
    }
    if (endpoint === "api/billing" || endpoint.startsWith("api/billing/")) {
      return endpoint.includes("/") ? billing[0] : billing
    }

    // Return empty array as fallback for unknown endpoints
    return []
  }
}

export async function postData(endpoint: string, data: any) {
  try {
    const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      throw new Error(`Error posting data: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`Error posting to ${endpoint}:`, error)
    throw error
  }
}

export async function updateData(endpoint: string, id: string | number, data: any) {
  try {
    const response = await fetch(`${API_BASE_URL}/${endpoint}/${id}`, {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      throw new Error(`Error updating data: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`Error updating in ${endpoint}:`, error)
    throw error
  }
}

export async function deleteData(endpoint: string, id: string | number) {
  try {
    const response = await fetch(`${API_BASE_URL}/${endpoint}/${id}`, {
      method: "DELETE",
      headers: getHeaders(),
    })

    if (!response.ok) {
      throw new Error(`Error deleting data: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error(`Error deleting from ${endpoint}:`, error)
    throw error
  }
}
