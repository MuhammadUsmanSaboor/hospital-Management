"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, FileText, BarChart2, PieChart, LineChart, Users, Receipt, Pill } from "lucide-react"
import Link from "next/link"

export function ReportsList() {
  const reports = [
    {
      id: "patient-admissions",
      title: "Patient Admissions",
      description: "Monthly patient admission statistics",
      icon: Users,
      type: "Bar Chart",
      lastGenerated: "2023-04-15",
    },
    {
      id: "revenue",
      title: "Revenue Analysis",
      description: "Financial performance and revenue breakdown",
      icon: Receipt,
      type: "Line Chart",
      lastGenerated: "2023-04-14",
    },
    {
      id: "department-performance",
      title: "Department Performance",
      description: "Metrics by department",
      icon: BarChart2,
      type: "Bar Chart",
      lastGenerated: "2023-04-13",
    },
    {
      id: "medication-usage",
      title: "Medication Usage",
      description: "Most prescribed medications",
      icon: Pill,
      type: "Pie Chart",
      lastGenerated: "2023-04-12",
    },
    {
      id: "bed-occupancy",
      title: "Bed Occupancy Rate",
      description: "Room and ward utilization",
      icon: LineChart,
      type: "Line Chart",
      lastGenerated: "2023-04-11",
    },
    {
      id: "doctor-performance",
      title: "Doctor Performance",
      description: "Appointments and patient feedback by doctor",
      icon: PieChart,
      type: "Pie Chart",
      lastGenerated: "2023-04-10",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {reports.map((report) => (
        <Card key={report.id} className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">{report.title}</CardTitle>
            <report.icon className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-3">{report.description}</CardDescription>
            <div className="flex items-center text-sm text-muted-foreground">
              <span className="mr-2">Type: {report.type}</span>
              <span className="ml-auto">Last generated: {report.lastGenerated}</span>
            </div>
            <div className="mt-4 flex gap-2">
              <Button variant="outline" size="sm" className="w-full" asChild>
                <Link href={`/reports/${report.id}`}>
                  <FileText className="mr-2 h-4 w-4" />
                  View
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
