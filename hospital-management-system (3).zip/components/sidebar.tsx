"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Users,
  UserRound,
  CalendarDays,
  Building2,
  Bed,
  Pill,
  Receipt,
  ClipboardList,
  Settings,
  LogOut,
  Menu,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useMobile } from "@/hooks/use-mobile"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export default function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const isMobile = useMobile()
  const [open, setOpen] = useState(false)

  const routes = [
    {
      label: "Dashboard",
      icon: BarChart3,
      href: "/",
      active: pathname === "/",
    },
    {
      label: "Patients",
      icon: Users,
      href: "/patients",
      active: pathname.startsWith("/patients"),
    },
    {
      label: "Doctors",
      icon: UserRound,
      href: "/doctors",
      active: pathname.startsWith("/doctors"),
    },
    {
      label: "Appointments",
      icon: CalendarDays,
      href: "/appointments",
      active: pathname.startsWith("/appointments"),
    },
    {
      label: "Departments",
      icon: Building2,
      href: "/departments",
      active: pathname.startsWith("/departments"),
    },
    {
      label: "Rooms & Wards",
      icon: Bed,
      href: "/rooms",
      active: pathname.startsWith("/rooms"),
    },
    {
      label: "Medications",
      icon: Pill,
      href: "/medications",
      active: pathname.startsWith("/medications"),
    },
    {
      label: "Billing",
      icon: Receipt,
      href: "/billing",
      active: pathname.startsWith("/billing"),
    },
    {
      label: "Reports",
      icon: ClipboardList,
      href: "/reports",
      active: pathname.startsWith("/reports"),
    },
  ]

  const SidebarContent = (
    <div className="space-y-4 py-4">
      <div className="px-4 py-2">
        <div className="flex items-center gap-2 px-2">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-3O8U5oytrG6ZnPtOLBeiJUrciKdEGf.png"
            alt="Medical Care Logo"
            className="h-8 w-8"
          />
          <h2 className="text-xl font-semibold tracking-tight">Medical Care</h2>
        </div>
      </div>
      <div className="px-3">
        {routes.map((route) => (
          <Link
            key={route.href}
            href={route.href}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-accent hover:text-accent-foreground",
              route.active ? "bg-accent text-accent-foreground" : "text-muted-foreground",
            )}
            onClick={() => isMobile && setOpen(false)}
          >
            <route.icon className="h-4 w-4" />
            {route.label}
          </Link>
        ))}
      </div>
    </div>
  )

  const SidebarFooter = (
    <div className="absolute bottom-4 left-4 right-4">
      <div className="space-y-2">
        <Link
          href="/settings"
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-accent hover:text-accent-foreground",
            pathname.startsWith("/settings") ? "bg-accent text-accent-foreground" : "text-muted-foreground",
          )}
          onClick={() => isMobile && setOpen(false)}
        >
          <Settings className="h-4 w-4" />
          Settings
        </Link>
        <Button variant="outline" className="justify-start gap-3">
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  )

  // For mobile, use a Sheet component
  if (isMobile) {
    return (
      <>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden absolute top-4 left-4 z-50">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="h-full flex flex-col">
              {SidebarContent}
              {SidebarFooter}
            </div>
          </SheetContent>
        </Sheet>
      </>
    )
  }

  // For desktop, render the sidebar directly
  return (
    <div className={cn("pb-12 w-64 border-r bg-background hidden md:block", className)}>
      {SidebarContent}
      {SidebarFooter}
    </div>
  )
}
