"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronLeft, ChevronRight, MoreHorizontal, Search, Edit, Trash2, FileText, Download } from "lucide-react"
import { dataService } from "@/lib/data-service"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function BillingList() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [billings, setBillings] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadBillings() {
      try {
        setIsLoading(true)
        const data = await dataService.getBilling()

        // Check if data is valid and has length
        if (data && Array.isArray(data) && data.length > 0) {
          setBillings(data)
        } else {
          console.log("No billing data returned or empty array received")
          // Set a default empty array if no data is returned
          setBillings([])
        }
      } catch (error) {
        console.error("Error loading billings:", error)
        // Set empty array on error to prevent component from breaking
        setBillings([])
        // You could also show a toast notification here
      } finally {
        setIsLoading(false)
      }
    }

    loadBillings()
  }, [])

  const filteredBillings = billings.filter((billing) => {
    const matchesSearch =
      (billing.patientName && billing.patientName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      billing.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      billing.patientId.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || billing.paymentStatus.toLowerCase() === statusFilter.toLowerCase()

    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search invoices..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice ID</TableHead>
              <TableHead>Patient</TableHead>
              <TableHead>Invoice Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center">
                  Loading invoices...
                </TableCell>
              </TableRow>
            ) : filteredBillings.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center">
                  No invoices found
                </TableCell>
              </TableRow>
            ) : (
              filteredBillings.map((billing) => (
                <TableRow key={billing.id}>
                  <TableCell className="font-medium">{billing.id}</TableCell>
                  <TableCell>{billing.patientName}</TableCell>
                  <TableCell>{billing.invoiceDate}</TableCell>
                  <TableCell>{billing.dueDate}</TableCell>
                  <TableCell>${Number.parseFloat(billing.totalAmount).toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        billing.paymentStatus === "Paid"
                          ? "outline"
                          : billing.paymentStatus === "Pending"
                            ? "default"
                            : billing.paymentStatus === "Overdue"
                              ? "destructive"
                              : "secondary"
                      }
                    >
                      {billing.paymentStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href={`/billing/${billing.id}`}>
                            <FileText className="mr-2 h-4 w-4" />
                            View details
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/billing/${billing.id}/edit`}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit invoice
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Download PDF
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this invoice?")) {
                              dataService
                                .deleteBilling(billing.id)
                                .then(() => {
                                  setBillings(billings.filter((b) => b.id !== billing.id))
                                })
                                .catch((error) => {
                                  console.error("Error deleting invoice:", error)
                                  alert("Failed to delete invoice")
                                })
                            }
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete invoice
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-end space-x-2 py-4">
        <Button variant="outline" size="sm">
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Button>
        <Button variant="outline" size="sm">
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
