import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export function RecentPatients() {
  const patients = [
    {
      id: "P001",
      name: "John Smith",
      age: 45,
      status: "Admitted",
      department: "Cardiology",
      date: "2023-04-15",
    },
    {
      id: "P002",
      name: "Sarah Johnson",
      age: 32,
      status: "Discharged",
      department: "Orthopedics",
      date: "2023-04-14",
    },
    {
      id: "P003",
      name: "Michael Brown",
      age: 58,
      status: "Admitted",
      department: "Neurology",
      date: "2023-04-13",
    },
    {
      id: "P004",
      name: "Emily Davis",
      age: 27,
      status: "Outpatient",
      department: "Gynecology",
      date: "2023-04-12",
    },
    {
      id: "P005",
      name: "Robert Wilson",
      age: 63,
      status: "Admitted",
      department: "Pulmonology",
      date: "2023-04-11",
    },
  ]

  return (
    <div className="space-y-8">
      {patients.map((patient) => (
        <div key={patient.id} className="flex items-center">
          <Avatar className="h-9 w-9">
            <AvatarFallback>
              {patient.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{patient.name}</p>
            <p className="text-sm text-muted-foreground">
              {patient.age} years • {patient.department}
            </p>
          </div>
          <div className="ml-auto">
            <Badge
              variant={
                patient.status === "Admitted" ? "default" : patient.status === "Discharged" ? "outline" : "secondary"
              }
            >
              {patient.status}
            </Badge>
          </div>
        </div>
      ))}
    </div>
  )
}
