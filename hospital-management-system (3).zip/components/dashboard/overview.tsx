"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const data = [
  {
    name: "Jan",
    patients: 157,
    appointments: 234,
  },
  {
    name: "Feb",
    patients: 165,
    appointments: 267,
  },
  {
    name: "Mar",
    patients: 184,
    appointments: 285,
  },
  {
    name: "Apr",
    patients: 191,
    appointments: 312,
  },
  {
    name: "May",
    patients: 202,
    appointments: 345,
  },
  {
    name: "Jun",
    patients: 198,
    appointments: 329,
  },
  {
    name: "Jul",
    patients: 210,
    appointments: 356,
  },
]

export function Overview() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
        <Tooltip />
        <Bar dataKey="patients" fill="#adfa1d" radius={[4, 4, 0, 0]} name="Patients" />
        <Bar dataKey="appointments" fill="#0ea5e9" radius={[4, 4, 0, 0]} name="Appointments" />
      </BarChart>
    </ResponsiveContainer>
  )
}
