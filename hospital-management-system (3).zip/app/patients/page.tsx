import { Suspense } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { PatientsList } from "@/components/patients/patients-list"
import { PatientsSkeleton } from "@/components/patients/patients-skeleton"
import Link from "next/link"

export default function PatientsPage() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Patients</h1>
        <Link href="/patients/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Patient
          </Button>
        </Link>
      </div>

      <Suspense fallback={<PatientsSkeleton />}>
        <PatientsList />
      </Suspense>
    </div>
  )
}
