import { notFound } from "next/navigation"
import { PatientForm } from "@/components/patients/patient-form"
import { dataService } from "@/lib/data-service"

async function getPatient(id: string) {
  try {
    return await dataService.getPatientById(id)
  } catch (error) {
    console.error(`Error fetching patient ${id}:`, error)
    return null
  }
}

export default async function EditPatientPage({ params }: { params: { id: string } }) {
  const patient = await getPatient(params.id)

  if (!patient) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Edit Patient</h1>
      <PatientForm initialData={patient} />
    </div>
  )
}
