import { PatientForm } from "@/components/patients/patient-form"

export default function NewPatientPage() {
  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Add New Patient</h1>
      <PatientForm />
    </div>
  )
}
