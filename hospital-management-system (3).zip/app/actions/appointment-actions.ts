"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for appointment data validation
const appointmentSchema = z.object({
  patientId: z.string().min(1, { message: "Patient is required." }),
  doctorId: z.string().min(1, { message: "Doctor is required." }),
  date: z.string().min(1, { message: "Date is required." }),
  time: z.string().min(1, { message: "Time is required." }),
  duration: z.string(),
  type: z.string(),
  status: z.string(),
  notes: z.string().optional(),
})

export async function createAppointment(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      patientId: formData.get("patientId") as string,
      doctorId: formData.get("doctorId") as string,
      date: formData.get("date") as string,
      time: formData.get("time") as string,
      duration: formData.get("duration") as string,
      type: formData.get("type") as string,
      status: formData.get("status") as string,
      notes: formData.get("notes") as string,
    }

    // Validate data
    const validatedData = appointmentSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating appointment:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the appointments page to show the new data
    revalidatePath("/appointments")

    return { success: true, message: "Appointment created successfully" }
  } catch (error) {
    console.error("Error creating appointment:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create appointment" }
  }
}

export async function updateAppointment(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      patientId: formData.get("patientId") as string,
      doctorId: formData.get("doctorId") as string,
      date: formData.get("date") as string,
      time: formData.get("time") as string,
      duration: formData.get("duration") as string,
      type: formData.get("type") as string,
      status: formData.get("status") as string,
      notes: formData.get("notes") as string,
    }

    // Validate data
    const validatedData = appointmentSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating appointment:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the appointments page to show the updated data
    revalidatePath("/appointments")
    revalidatePath(`/appointments/${id}`)

    return { success: true, message: "Appointment updated successfully" }
  } catch (error) {
    console.error("Error updating appointment:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update appointment" }
  }
}

export async function deleteAppointment(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting appointment:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the appointments page to reflect the deletion
    revalidatePath("/appointments")

    return { success: true, message: "Appointment deleted successfully" }
  } catch (error) {
    console.error("Error deleting appointment:", error)
    return { success: false, message: "Failed to delete appointment" }
  }
}
