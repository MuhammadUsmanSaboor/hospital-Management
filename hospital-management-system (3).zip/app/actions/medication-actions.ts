"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for medication data validation
const medicationSchema = z.object({
  name: z.string().min(2, { message: "Medication name must be at least 2 characters." }),
  description: z.string().optional(),
  category: z.string(),
  dosage: z.string(),
  manufacturer: z.string().optional(),
  stockQuantity: z.string(),
  unitPrice: z.string(),
  expiryDate: z.string().optional(),
  sideEffects: z.string().optional(),
  storageInstructions: z.string().optional(),
})

export async function createMedication(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      category: formData.get("category") as string,
      dosage: formData.get("dosage") as string,
      manufacturer: formData.get("manufacturer") as string,
      stockQuantity: formData.get("stockQuantity") as string,
      unitPrice: formData.get("unitPrice") as string,
      expiryDate: formData.get("expiryDate") as string,
      sideEffects: formData.get("sideEffects") as string,
      storageInstructions: formData.get("storageInstructions") as string,
    }

    // Validate data
    const validatedData = medicationSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating medication:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the medications page to show the new data
    revalidatePath("/medications")

    return { success: true, message: "Medication created successfully" }
  } catch (error) {
    console.error("Error creating medication:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create medication" }
  }
}

export async function updateMedication(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      category: formData.get("category") as string,
      dosage: formData.get("dosage") as string,
      manufacturer: formData.get("manufacturer") as string,
      stockQuantity: formData.get("stockQuantity") as string,
      unitPrice: formData.get("unitPrice") as string,
      expiryDate: formData.get("expiryDate") as string,
      sideEffects: formData.get("sideEffects") as string,
      storageInstructions: formData.get("storageInstructions") as string,
    }

    // Validate data
    const validatedData = medicationSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating medication:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the medications page to show the updated data
    revalidatePath("/medications")
    revalidatePath(`/medications/${id}`)

    return { success: true, message: "Medication updated successfully" }
  } catch (error) {
    console.error("Error updating medication:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update medication" }
  }
}

export async function deleteMedication(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting medication:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the medications page to reflect the deletion
    revalidatePath("/medications")

    return { success: true, message: "Medication deleted successfully" }
  } catch (error) {
    console.error("Error deleting medication:", error)
    return { success: false, message: "Failed to delete medication" }
  }
}
