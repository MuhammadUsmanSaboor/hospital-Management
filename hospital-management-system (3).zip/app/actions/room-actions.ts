"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for room data validation
const roomSchema = z.object({
  roomNumber: z.string().min(1, { message: "Room number is required." }),
  type: z.string().min(1, { message: "Room type is required." }),
  floor: z.string(),
  department: z.string().optional(),
  capacity: z.string(),
  status: z.string(),
  rate: z.string().optional(),
  features: z.string().optional(),
})

export async function createRoom(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      roomNumber: formData.get("roomNumber") as string,
      type: formData.get("type") as string,
      floor: formData.get("floor") as string,
      department: formData.get("department") as string,
      capacity: formData.get("capacity") as string,
      status: formData.get("status") as string,
      rate: formData.get("rate") as string,
      features: formData.get("features") as string,
    }

    // Validate data
    const validatedData = roomSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating room:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the rooms page to show the new data
    revalidatePath("/rooms")

    return { success: true, message: "Room created successfully" }
  } catch (error) {
    console.error("Error creating room:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create room" }
  }
}

export async function updateRoom(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      roomNumber: formData.get("roomNumber") as string,
      type: formData.get("type") as string,
      floor: formData.get("floor") as string,
      department: formData.get("department") as string,
      capacity: formData.get("capacity") as string,
      status: formData.get("status") as string,
      rate: formData.get("rate") as string,
      features: formData.get("features") as string,
    }

    // Validate data
    const validatedData = roomSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating room:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the rooms page to show the updated data
    revalidatePath("/rooms")
    revalidatePath(`/rooms/${id}`)

    return { success: true, message: "Room updated successfully" }
  } catch (error) {
    console.error("Error updating room:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update room" }
  }
}

export async function deleteRoom(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting room:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the rooms page to reflect the deletion
    revalidatePath("/rooms")

    return { success: true, message: "Room deleted successfully" }
  } catch (error) {
    console.error("Error deleting room:", error)
    return { success: false, message: "Failed to delete room" }
  }
}
