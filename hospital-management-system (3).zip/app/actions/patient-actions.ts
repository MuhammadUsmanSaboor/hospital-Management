"use server"

import { revalidatePath } from "next/cache"
import { dataService } from "@/lib/data-service"

export async function createPatient(formData: FormData) {
  try {
    // Extract data from form
    const firstName = formData.get("firstName") as string
    const lastName = formData.get("lastName") as string
    const dateOfBirth = formData.get("dateOfBirth") as string
    const gender = formData.get("gender") as string
    const email = formData.get("email") as string
    const phone = formData.get("phone") as string
    const address = formData.get("address") as string

    // Calculate age
    const birthDate = new Date(dateOfBirth)
    const today = new Date()
    let age = today.getFullYear() - birthDate.getFullYear()
    const m = today.getMonth() - birthDate.getMonth()
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }

    // Create patient object
    const patient = {
      name: `${firstName} ${lastName}`,
      age,
      gender,
      email,
      phone,
      address,
      status: "Registered",
      firstName,
      lastName,
      dateOfBirth,
      // Add other fields as needed
    }

    // Save patient
    await dataService.createPatient(patient)

    // Revalidate the patients page
    revalidatePath("/patients")

    return { success: true, message: "Patient created successfully" }
  } catch (error) {
    console.error("Error creating patient:", error)
    return { success: false, message: "Failed to create patient" }
  }
}

export async function updatePatient(id: string, formData: FormData) {
  try {
    // Extract data from form
    const firstName = formData.get("firstName") as string
    const lastName = formData.get("lastName") as string
    const dateOfBirth = formData.get("dateOfBirth") as string
    const gender = formData.get("gender") as string
    const email = formData.get("email") as string
    const phone = formData.get("phone") as string
    const address = formData.get("address") as string

    // Calculate age
    const birthDate = new Date(dateOfBirth)
    const today = new Date()
    let age = today.getFullYear() - birthDate.getFullYear()
    const m = today.getMonth() - birthDate.getMonth()
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }

    // Create patient object
    const patient = {
      name: `${firstName} ${lastName}`,
      age,
      gender,
      email,
      phone,
      address,
      firstName,
      lastName,
      dateOfBirth,
      // Add other fields as needed
    }

    // Update patient
    await dataService.updatePatient(id, patient)

    // Revalidate the patients page
    revalidatePath("/patients")
    revalidatePath(`/patients/${id}`)

    return { success: true, message: "Patient updated successfully" }
  } catch (error) {
    console.error("Error updating patient:", error)
    return { success: false, message: "Failed to update patient" }
  }
}

export async function deletePatient(id: string) {
  try {
    // Delete patient
    await dataService.deletePatient(id)

    // Revalidate the patients page
    revalidatePath("/patients")

    return { success: true, message: "Patient deleted successfully" }
  } catch (error) {
    console.error("Error deleting patient:", error)
    return { success: false, message: "Failed to delete patient" }
  }
}
