"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for doctor data validation
const doctorSchema = z.object({
  firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
  specialization: z.string().min(2, { message: "Specialization is required." }),
  qualification: z.string().min(2, { message: "Qualification is required." }),
  experience: z.string(),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Phone number must be at least 10 characters." }),
  address: z.string().min(5, { message: "Address must be at least 5 characters." }),
  joiningDate: z.string(),
  department: z.string(),
  consultationFee: z.string(),
  status: z.string(),
})

export async function createDoctor(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      firstName: formData.get("firstName") as string,
      lastName: formData.get("lastName") as string,
      specialization: formData.get("specialization") as string,
      qualification: formData.get("qualification") as string,
      experience: formData.get("experience") as string,
      email: formData.get("email") as string,
      phone: formData.get("phone") as string,
      address: formData.get("address") as string,
      joiningDate: formData.get("joiningDate") as string,
      department: formData.get("department") as string,
      consultationFee: formData.get("consultationFee") as string,
      status: formData.get("status") as string,
    }

    // Validate data
    const validatedData = doctorSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating doctor:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the doctors page to show the new data
    revalidatePath("/doctors")

    return { success: true, message: "Doctor created successfully" }
  } catch (error) {
    console.error("Error creating doctor:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create doctor" }
  }
}

export async function updateDoctor(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      firstName: formData.get("firstName") as string,
      lastName: formData.get("lastName") as string,
      specialization: formData.get("specialization") as string,
      qualification: formData.get("qualification") as string,
      experience: formData.get("experience") as string,
      email: formData.get("email") as string,
      phone: formData.get("phone") as string,
      address: formData.get("address") as string,
      joiningDate: formData.get("joiningDate") as string,
      department: formData.get("department") as string,
      consultationFee: formData.get("consultationFee") as string,
      status: formData.get("status") as string,
    }

    // Validate data
    const validatedData = doctorSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating doctor:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the doctors page to show the updated data
    revalidatePath("/doctors")
    revalidatePath(`/doctors/${id}`)

    return { success: true, message: "Doctor updated successfully" }
  } catch (error) {
    console.error("Error updating doctor:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update doctor" }
  }
}

export async function deleteDoctor(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting doctor:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the doctors page to reflect the deletion
    revalidatePath("/doctors")

    return { success: true, message: "Doctor deleted successfully" }
  } catch (error) {
    console.error("Error deleting doctor:", error)
    return { success: false, message: "Failed to delete doctor" }
  }
}
