"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for billing data validation
const billingSchema = z.object({
  patientId: z.string().min(1, { message: "Patient is required." }),
  invoiceDate: z.string().min(1, { message: "Invoice date is required." }),
  dueDate: z.string().min(1, { message: "Due date is required." }),
  totalAmount: z.string().min(1, { message: "Total amount is required." }),
  paymentStatus: z.string(),
  paymentMethod: z.string().optional(),
  paymentDate: z.string().optional(),
  description: z.string().optional(),
})

export async function createBilling(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      patientId: formData.get("patientId") as string,
      invoiceDate: formData.get("invoiceDate") as string,
      dueDate: formData.get("dueDate") as string,
      totalAmount: formData.get("totalAmount") as string,
      paymentStatus: formData.get("paymentStatus") as string,
      paymentMethod: formData.get("paymentMethod") as string,
      paymentDate: formData.get("paymentDate") as string,
      description: formData.get("description") as string,
    }

    // Validate data
    const validatedData = billingSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating billing:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the billing page to show the new data
    revalidatePath("/billing")

    return { success: true, message: "Billing created successfully" }
  } catch (error) {
    console.error("Error creating billing:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create billing" }
  }
}

export async function updateBilling(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      patientId: formData.get("patientId") as string,
      invoiceDate: formData.get("invoiceDate") as string,
      dueDate: formData.get("dueDate") as string,
      totalAmount: formData.get("totalAmount") as string,
      paymentStatus: formData.get("paymentStatus") as string,
      paymentMethod: formData.get("paymentMethod") as string,
      paymentDate: formData.get("paymentDate") as string,
      description: formData.get("description") as string,
    }

    // Validate data
    const validatedData = billingSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating billing:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the billing page to show the updated data
    revalidatePath("/billing")
    revalidatePath(`/billing/${id}`)

    return { success: true, message: "Billing updated successfully" }
  } catch (error) {
    console.error("Error updating billing:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update billing" }
  }
}

export async function deleteBilling(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting billing:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the billing page to reflect the deletion
    revalidatePath("/billing")

    return { success: true, message: "Billing deleted successfully" }
  } catch (error) {
    console.error("Error deleting billing:", error)
    return { success: false, message: "Failed to delete billing" }
  }
}
