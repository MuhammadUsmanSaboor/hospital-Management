"use server"

import { revalidatePath } from "next/cache"
import { z } from "zod"

// Define the schema for department data validation
const departmentSchema = z.object({
  name: z.string().min(2, { message: "Department name must be at least 2 characters." }),
  description: z.string().optional(),
  headOfDepartment: z.string().optional(),
  location: z.string().optional(),
  contactNumber: z.string().optional(),
  email: z.string().email({ message: "Please enter a valid email address." }).optional(),
})

export async function createDepartment(formData: FormData) {
  try {
    // Extract data from form
    const data = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      headOfDepartment: formData.get("headOfDepartment") as string,
      location: formData.get("location") as string,
      contactNumber: formData.get("contactNumber") as string,
      email: formData.get("email") as string,
    }

    // Validate data
    const validatedData = departmentSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Creating department:", validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the departments page to show the new data
    revalidatePath("/departments")

    return { success: true, message: "Department created successfully" }
  } catch (error) {
    console.error("Error creating department:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to create department" }
  }
}

export async function updateDepartment(id: string, formData: FormData) {
  try {
    // Extract data from form
    const data = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      headOfDepartment: formData.get("headOfDepartment") as string,
      location: formData.get("location") as string,
      contactNumber: formData.get("contactNumber") as string,
      email: formData.get("email") as string,
    }

    // Validate data
    const validatedData = departmentSchema.parse(data)

    // In a real application, you would send this data to your backend API
    console.log("Updating department:", id, validatedData)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the departments page to show the updated data
    revalidatePath("/departments")
    revalidatePath(`/departments/${id}`)

    return { success: true, message: "Department updated successfully" }
  } catch (error) {
    console.error("Error updating department:", error)
    if (error instanceof z.ZodError) {
      return { success: false, message: "Validation error", errors: error.errors }
    }
    return { success: false, message: "Failed to update department" }
  }
}

export async function deleteDepartment(id: string) {
  try {
    // In a real application, you would send this request to your backend API
    console.log("Deleting department:", id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Revalidate the departments page to reflect the deletion
    revalidatePath("/departments")

    return { success: true, message: "Department deleted successfully" }
  } catch (error) {
    console.error("Error deleting department:", error)
    return { success: false, message: "Failed to delete department" }
  }
}
