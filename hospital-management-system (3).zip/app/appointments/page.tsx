import { Suspense } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AppointmentsList } from "@/components/appointments/appointments-list"
import { AppointmentsSkeleton } from "@/components/appointments/appointments-skeleton"
import Link from "next/link"

export default function AppointmentsPage() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Appointments</h1>
        <Link href="/appointments/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Schedule Appointment
          </Button>
        </Link>
      </div>

      <Suspense fallback={<AppointmentsSkeleton />}>
        <AppointmentsList />
      </Suspense>
    </div>
  )
}
