import { Suspense } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { RoomsList } from "@/components/rooms/rooms-list"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"

function RoomsSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-10 w-full" />
      <div className="rounded-md border">
        <div className="h-[400px] w-full bg-muted/10" />
      </div>
    </div>
  )
}

export default function RoomsPage() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Rooms & Wards</h1>
        <Link href="/rooms/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Room
          </Button>
        </Link>
      </div>

      <Suspense fallback={<RoomsSkeleton />}>
        <RoomsList />
      </Suspense>
    </div>
  )
}
