import { notFound } from "next/navigation"
import { RoomForm } from "@/components/rooms/room-form"
import { dataService } from "@/lib/data-service"

async function getRoom(id: string) {
  try {
    return await dataService.getRoomById(id)
  } catch (error) {
    console.error(`Error fetching room ${id}:`, error)
    return null
  }
}

export default async function EditRoomPage({ params }: { params: { id: string } }) {
  const room = await getRoom(params.id)

  if (!room) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Edit Room</h1>
      <RoomForm initialData={room} />
    </div>
  )
}
