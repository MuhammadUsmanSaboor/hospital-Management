import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Edit } from "lucide-react"
import { dataService } from "@/lib/data-service"

async function getRoom(id: string) {
  try {
    return await dataService.getRoomById(id)
  } catch (error) {
    console.error(`Error fetching room ${id}:`, error)
    return null
  }
}

export default async function RoomDetailPage({ params }: { params: { id: string } }) {
  const room = await getRoom(params.id)

  if (!room) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/rooms">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Room Details</h1>
        </div>
        <Link href={`/rooms/${params.id}/edit`}>
          <Button>
            <Edit className="mr-2 h-4 w-4" />
            Edit Room
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Room Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Room ID</h3>
              <p className="text-base">{room.id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Room Number</h3>
              <p className="text-base">{room.roomNumber}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Type</h3>
              <p className="text-base">{room.type}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Floor</h3>
              <p className="text-base">{room.floor}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Department</h3>
              <p className="text-base">{room.department || "Not assigned"}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Capacity</h3>
              <p className="text-base">
                {room.capacity} {Number.parseInt(room.capacity) > 1 ? "beds" : "bed"}
              </p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Rate</h3>
              <p className="text-base">${room.rate}/day</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
              <Badge
                variant={room.status === "Available" ? "outline" : room.status === "Occupied" ? "default" : "secondary"}
              >
                {room.status}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {room.features && (
        <Card>
          <CardHeader>
            <CardTitle>Features</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{room.features}</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Current Occupancy</CardTitle>
        </CardHeader>
        <CardContent>
          {room.status === "Occupied" ? (
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Patient:</span>
                <span className="font-medium">John Smith (P001)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Admission Date:</span>
                <span className="font-medium">2023-04-10</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Expected Discharge:</span>
                <span className="font-medium">2023-04-17</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Attending Doctor:</span>
                <span className="font-medium">Dr. James Wilson</span>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground">This room is currently {room.status.toLowerCase()}.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
