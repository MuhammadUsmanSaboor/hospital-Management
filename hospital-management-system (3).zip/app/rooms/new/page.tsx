import { RoomForm } from "@/components/rooms/room-form"

export default function NewRoomPage() {
  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Add New Room</h1>
      <RoomForm />
    </div>
  )
}
