import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Edit, Download, Printer, Send } from "lucide-react"
import { dataService } from "@/lib/data-service"
import { Separator } from "@/components/ui/separator"

async function getBilling(id: string) {
  try {
    return await dataService.getBillingById(id)
  } catch (error) {
    console.error(`Error fetching billing ${id}:`, error)
    return null
  }
}

export default async function BillingDetailPage({ params }: { params: { id: string } }) {
  const billing = await getBilling(params.id)

  if (!billing) {
    notFound()
  }

  // Mock billing items
  const billingItems = [
    {
      id: "BI001",
      description: "Room Charges (Private Room)",
      quantity: "5",
      unitPrice: "500",
      total: "2500",
    },
    {
      id: "BI002",
      description: "Doctor Consultation",
      quantity: "3",
      unitPrice: "200",
      total: "600",
    },
    {
      id: "BI003",
      description: "Laboratory Tests",
      quantity: "1",
      unitPrice: "350",
      total: "350",
    },
    {
      id: "BI004",
      description: "Medications",
      quantity: "1",
      unitPrice: "450",
      total: "450",
    },
  ]

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/billing">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Invoice Details</h1>
        </div>
        <div className="flex gap-2">
          <Link href={`/billing/${params.id}/edit`}>
            <Button>
              <Edit className="mr-2 h-4 w-4" />
              Edit Invoice
            </Button>
          </Link>
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button variant="outline">
            <Send className="mr-2 h-4 w-4" />
            Send
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="text-2xl">Invoice #{billing.id}</CardTitle>
              <p className="text-muted-foreground">
                Status:{" "}
                <Badge
                  variant={
                    billing.paymentStatus === "Paid"
                      ? "outline"
                      : billing.paymentStatus === "Pending"
                        ? "default"
                        : billing.paymentStatus === "Overdue"
                          ? "destructive"
                          : "secondary"
                  }
                >
                  {billing.paymentStatus}
                </Badge>
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Invoice Date: {billing.invoiceDate}</p>
              <p className="text-sm text-muted-foreground">Due Date: {billing.dueDate}</p>
              {billing.paymentDate && (
                <p className="text-sm text-muted-foreground">Payment Date: {billing.paymentDate}</p>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div>
              <h3 className="mb-2 text-sm font-medium">Bill To:</h3>
              <p className="font-medium">{billing.patientName}</p>
              <p className="text-sm text-muted-foreground">Patient ID: {billing.patientId}</p>
              <p className="text-sm text-muted-foreground">123 Patient Street</p>
              <p className="text-sm text-muted-foreground">Anytown, ST 12345</p>
            </div>
            <div>
              <h3 className="mb-2 text-sm font-medium">From:</h3>
              <p className="font-medium">Medical Care Hospital</p>
              <p className="text-sm text-muted-foreground">123 Medical Drive</p>
              <p className="text-sm text-muted-foreground">Healthcare City, ST 54321</p>
              <p className="text-sm text-muted-foreground">Phone: (555) 123-4567</p>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="py-3 text-left font-medium">Item</th>
                  <th className="py-3 text-right font-medium">Quantity</th>
                  <th className="py-3 text-right font-medium">Unit Price</th>
                  <th className="py-3 text-right font-medium">Total</th>
                </tr>
              </thead>
              <tbody>
                {billingItems.map((item) => (
                  <tr key={item.id} className="border-b">
                    <td className="py-3 text-left">{item.description}</td>
                    <td className="py-3 text-right">{item.quantity}</td>
                    <td className="py-3 text-right">${item.unitPrice}</td>
                    <td className="py-3 text-right">${item.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-8 flex flex-col items-end">
            <div className="w-full max-w-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal:</span>
                <span>$3,900.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax (5%):</span>
                <span>$195.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Discount:</span>
                <span>-$195.00</span>
              </div>
              <Separator />
              <div className="flex justify-between font-medium">
                <span>Total:</span>
                <span>${billing.totalAmount}</span>
              </div>
            </div>
          </div>

          {billing.description && (
            <div className="mt-8">
              <h3 className="mb-2 text-sm font-medium">Notes:</h3>
              <p className="text-sm text-muted-foreground">{billing.description}</p>
            </div>
          )}

          {billing.paymentMethod && (
            <div className="mt-4">
              <h3 className="mb-2 text-sm font-medium">Payment Information:</h3>
              <p className="text-sm text-muted-foreground">
                Method: {billing.paymentMethod}
                {billing.paymentDate && ` | Date: ${billing.paymentDate}`}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
