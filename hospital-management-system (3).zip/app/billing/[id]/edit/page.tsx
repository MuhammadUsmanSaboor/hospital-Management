import { notFound } from "next/navigation"
import { BillingForm } from "@/components/billing/billing-form"
import { dataService } from "@/lib/data-service"

async function getBilling(id: string) {
  try {
    return await dataService.getBillingById(id)
  } catch (error) {
    console.error(`Error fetching billing ${id}:`, error)
    return null
  }
}

export default async function EditBillingPage({ params }: { params: { id: string } }) {
  const billing = await getBilling(params.id)

  if (!billing) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Edit Invoice</h1>
      <BillingForm initialData={billing} />
    </div>
  )
}
