import { BillingForm } from "@/components/billing/billing-form"

export default function NewBillingPage() {
  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Create New Invoice</h1>
      <BillingForm />
    </div>
  )
}
