import { notFound } from "next/navigation"
import { DepartmentForm } from "@/components/departments/department-form"
import { dataService } from "@/lib/data-service"

async function getDepartment(id: string) {
  try {
    return await dataService.getDepartmentById(id)
  } catch (error) {
    console.error(`Error fetching department ${id}:`, error)
    return null
  }
}

export default async function EditDepartmentPage({ params }: { params: { id: string } }) {
  const department = await getDepartment(params.id)

  if (!department) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Edit Department</h1>
      <DepartmentForm initialData={department} />
    </div>
  )
}
