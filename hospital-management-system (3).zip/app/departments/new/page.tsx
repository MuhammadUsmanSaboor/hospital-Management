import { DepartmentForm } from "@/components/departments/department-form"

export default function NewDepartmentPage() {
  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Add New Department</h1>
      <DepartmentForm />
    </div>
  )
}
