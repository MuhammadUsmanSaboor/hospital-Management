import { NextResponse } from "next/server"

export async function GET() {
  try {
    // In a real application, you would fetch data from your backend
    // For now, we'll return mock data
    const appointments = [
      {
        id: "A001",
        patientName: "John Smith",
        patientId: "P001",
        doctorName: "Dr. James Wilson",
        doctorId: "D001",
        date: "2023-04-15",
        time: "09:00 AM",
        department: "Cardiology",
        status: "Scheduled",
      },
      {
        id: "A002",
        patientName: "Sarah Johnson",
        patientId: "P002",
        doctorName: "Dr. Emily Johnson",
        doctorId: "D002",
        date: "2023-04-15",
        time: "10:30 AM",
        department: "Neurology",
        status: "Completed",
      },
      {
        id: "A003",
        patientName: "Michael Brown",
        patientId: "P003",
        doctorName: "Dr. Robert Smith",
        doctorId: "D003",
        date: "2023-04-16",
        time: "11:00 AM",
        department: "Orthopedics",
        status: "Scheduled",
      },
      {
        id: "A004",
        patientName: "Emily Davis",
        patientId: "P004",
        doctorName: "Dr. Sarah Davis",
        doctorId: "D004",
        date: "2023-04-16",
        time: "02:00 PM",
        department: "Pediatrics",
        status: "Cancelled",
      },
      {
        id: "A005",
        patientName: "Robert Wilson",
        patientId: "P005",
        doctorName: "Dr. Michael Brown",
        doctorId: "D005",
        date: "2023-04-17",
        time: "03:30 PM",
        department: "Dermatology",
        status: "Scheduled",
      },
    ]

    return NextResponse.json(appointments)
  } catch (error) {
    console.error("Error fetching appointments:", error)
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // In a real application, you would save this data to your backend
    console.log("Creating appointment:", data)

    // Return a success response with a new ID
    return NextResponse.json({
      id: `A${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")}`,
      ...data,
      success: true,
    })
  } catch (error) {
    console.error("Error creating appointment:", error)
    return NextResponse.json({ error: "Failed to create appointment" }, { status: 500 })
  }
}
