import { NextResponse } from "next/server"
import { dataService } from "@/lib/data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const patient = await dataService.getPatientById(id)

    if (!patient) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 })
    }

    return NextResponse.json(patient)
  } catch (error) {
    console.error(`Error fetching patient ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch patient" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()
    const updatedPatient = await dataService.updatePatient(id, data)
    return NextResponse.json(updatedPatient)
  } catch (error) {
    console.error(`Error updating patient ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update patient" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    await dataService.deletePatient(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting patient ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete patient" }, { status: 500 })
  }
}
