import { NextResponse } from "next/server"
import { dataService } from "@/lib/data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const billing = await dataService.getBillingById(id)

    if (!billing) {
      return NextResponse.json({ error: "Billing not found" }, { status: 404 })
    }

    return NextResponse.json(billing)
  } catch (error) {
    console.error(`Error fetching billing ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch billing" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()
    const updatedBilling = await dataService.updateBilling(id, data)
    return NextResponse.json(updatedBilling)
  } catch (error) {
    console.error(`Error updating billing ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update billing" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    await dataService.deleteBilling(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting billing ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete billing" }, { status: 500 })
  }
}
