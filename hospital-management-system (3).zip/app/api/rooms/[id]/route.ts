import { NextResponse } from "next/server"
import { dataService } from "@/lib/data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const room = await dataService.getRoomById(id)

    if (!room) {
      return NextResponse.json({ error: "Room not found" }, { status: 404 })
    }

    return NextResponse.json(room)
  } catch (error) {
    console.error(`Error fetching room ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch room" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()
    const updatedRoom = await dataService.updateRoom(id, data)
    return NextResponse.json(updatedRoom)
  } catch (error) {
    console.error(`Error updating room ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update room" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    await dataService.deleteRoom(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting room ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete room" }, { status: 500 })
  }
}
