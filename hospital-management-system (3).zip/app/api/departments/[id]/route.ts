import { NextResponse } from "next/server"
import { dataService } from "@/lib/data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const department = await dataService.getDepartmentById(id)

    if (!department) {
      return NextResponse.json({ error: "Department not found" }, { status: 404 })
    }

    return NextResponse.json(department)
  } catch (error) {
    console.error(`Error fetching department ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch department" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()
    const updatedDepartment = await dataService.updateDepartment(id, data)
    return NextResponse.json(updatedDepartment)
  } catch (error) {
    console.error(`Error updating department ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update department" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    await dataService.deleteDepartment(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting department ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete department" }, { status: 500 })
  }
}
