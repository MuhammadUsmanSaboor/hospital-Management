import { NextResponse } from "next/server"
import { dataService } from "@/lib/data-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const medication = await dataService.getMedicationById(id)

    if (!medication) {
      return NextResponse.json({ error: "Medication not found" }, { status: 404 })
    }

    return NextResponse.json(medication)
  } catch (error) {
    console.error(`Error fetching medication ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch medication" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()
    const updatedMedication = await dataService.updateMedication(id, data)
    return NextResponse.json(updatedMedication)
  } catch (error) {
    console.error(`Error updating medication ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update medication" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    await dataService.deleteMedication(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting medication ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete medication" }, { status: 500 })
  }
}
