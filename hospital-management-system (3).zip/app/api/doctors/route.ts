import { NextResponse } from "next/server"

export async function GET() {
  try {
    // In a real application, you would fetch data from your backend
    // For now, we'll return mock data
    const doctors = [
      {
        id: "D001",
        name: "Dr. James Wilson",
        specialization: "Cardiology",
        phone: "555-111-2222",
        email: "james.wilson@hospital.com",
        status: "Active",
      },
      {
        id: "D002",
        name: "Dr. Emily Johnson",
        specialization: "Neurology",
        phone: "555-222-3333",
        email: "emily.johnson@hospital.com",
        status: "Active",
      },
      {
        id: "D003",
        name: "Dr. Robert Smith",
        specialization: "Orthopedics",
        phone: "555-333-4444",
        email: "robert.smith@hospital.com",
        status: "On Leave",
      },
      {
        id: "D004",
        name: "Dr. Sarah Davis",
        specialization: "Pediatrics",
        phone: "555-444-5555",
        email: "sarah.davis@hospital.com",
        status: "Active",
      },
      {
        id: "D005",
        name: "Dr. Michael Brown",
        specialization: "Dermatology",
        phone: "555-555-6666",
        email: "michael.brown@hospital.com",
        status: "Active",
      },
    ]

    return NextResponse.json(doctors)
  } catch (error) {
    console.error("Error fetching doctors:", error)
    return NextResponse.json({ error: "Failed to fetch doctors" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // In a real application, you would save this data to your backend
    console.log("Creating doctor:", data)

    // Return a success response with a new ID
    return NextResponse.json({
      id: `D${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")}`,
      ...data,
      success: true,
    })
  } catch (error) {
    console.error("Error creating doctor:", error)
    return NextResponse.json({ error: "Failed to create doctor" }, { status: 500 })
  }
}
