import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // In a real application, you would fetch this doctor from your backend
    // For now, we'll return mock data
    const doctor = {
      id: id,
      firstName: "James",
      lastName: "Wilson",
      specialization: "Cardiology",
      qualification: "MD, FACC",
      experience: "15",
      email: "james.wilson@hospital.com",
      phone: "555-111-2222",
      address: "456 Hospital Ave",
      joiningDate: "2010-03-15",
      department: "Cardiology",
      consultationFee: "200",
      status: "Active",
    }

    return NextResponse.json(doctor)
  } catch (error) {
    console.error(`Error fetching doctor ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to fetch doctor" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()

    // In a real application, you would update this doctor in your backend
    console.log("Updating doctor:", id, data)

    // Return a success response
    return NextResponse.json({ id, ...data, success: true })
  } catch (error) {
    console.error(`Error updating doctor ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to update doctor" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // In a real application, you would delete this doctor from your backend
    console.log("Deleting doctor:", id)

    // Return a success response
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error deleting doctor ${params.id}:`, error)
    return NextResponse.json({ error: "Failed to delete doctor" }, { status: 500 })
  }
}
