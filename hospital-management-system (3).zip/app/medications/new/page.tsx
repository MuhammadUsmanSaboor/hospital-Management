import { MedicationForm } from "@/components/medications/medication-form"

export default function NewMedicationPage() {
  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Add New Medication</h1>
      <MedicationForm />
    </div>
  )
}
