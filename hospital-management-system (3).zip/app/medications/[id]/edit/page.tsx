import { notFound } from "next/navigation"
import { MedicationForm } from "@/components/medications/medication-form"
import { dataService } from "@/lib/data-service"

async function getMedication(id: string) {
  try {
    return await dataService.getMedicationById(id)
  } catch (error) {
    console.error(`Error fetching medication ${id}:`, error)
    return null
  }
}

export default async function EditMedicationPage({ params }: { params: { id: string } }) {
  const medication = await getMedication(params.id)

  if (!medication) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-bold">Edit Medication</h1>
      <MedicationForm initialData={medication} />
    </div>
  )
}
