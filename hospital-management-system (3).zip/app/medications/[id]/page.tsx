import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Edit, AlertTriangle } from "lucide-react"
import { dataService } from "@/lib/data-service"

async function getMedication(id: string) {
  try {
    return await dataService.getMedicationById(id)
  } catch (error) {
    console.error(`Error fetching medication ${id}:`, error)
    return null
  }
}

export default async function MedicationDetailPage({ params }: { params: { id: string } }) {
  const medication = await getMedication(params.id)

  if (!medication) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/medications">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Medication Details</h1>
        </div>
        <Link href={`/medications/${params.id}/edit`}>
          <Button>
            <Edit className="mr-2 h-4 w-4" />
            Edit Medication
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Medication Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Medication ID</h3>
              <p className="text-base">{medication.id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Name</h3>
              <p className="text-base">{medication.name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Category</h3>
              <p className="text-base">{medication.category}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Dosage</h3>
              <p className="text-base">{medication.dosage}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Manufacturer</h3>
              <p className="text-base">{medication.manufacturer || "Not specified"}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Stock Quantity</h3>
              <p className="text-base">{medication.stockQuantity} units</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Unit Price</h3>
              <p className="text-base">${Number.parseFloat(medication.unitPrice).toFixed(2)}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Expiry Date</h3>
              <p className="text-base">{medication.expiryDate || "Not specified"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {medication.description && (
        <Card>
          <CardHeader>
            <CardTitle>Description</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{medication.description}</p>
          </CardContent>
        </Card>
      )}

      {medication.sideEffects && (
        <Card>
          <CardHeader className="flex flex-row items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <CardTitle>Side Effects</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{medication.sideEffects}</p>
          </CardContent>
        </Card>
      )}

      {medication.storageInstructions && (
        <Card>
          <CardHeader>
            <CardTitle>Storage Instructions</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{medication.storageInstructions}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
