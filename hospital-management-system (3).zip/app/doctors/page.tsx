import { Suspense } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { DoctorsList } from "@/components/doctors/doctors-list"
import { DoctorsSkeleton } from "@/components/doctors/doctors-skeleton"
import Link from "next/link"

export default function DoctorsPage() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Doctors</h1>
        <Link href="/doctors/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Doctor
          </Button>
        </Link>
      </div>

      <Suspense fallback={<DoctorsSkeleton />}>
        <DoctorsList />
      </Suspense>
    </div>
  )
}
