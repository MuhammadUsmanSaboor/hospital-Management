"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, Printer, Share2 } from "lucide-react"
import Link from "next/link"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const data = [
  { month: "Jan", admissions: 65, discharges: 55 },
  { month: "Feb", admissions: 59, discharges: 49 },
  { month: "Mar", admissions: 80, discharges: 72 },
  { month: "Apr", admissions: 81, discharges: 78 },
  { month: "May", admissions: 56, discharges: 50 },
  { month: "Jun", admissions: 55, discharges: 42 },
  { month: "Jul", admissions: 40, discharges: 35 },
  { month: "Aug", admissions: 45, discharges: 40 },
  { month: "Sep", admissions: 60, discharges: 55 },
  { month: "Oct", admissions: 70, discharges: 65 },
  { month: "Nov", admissions: 75, discharges: 68 },
  { month: "Dec", admissions: 85, discharges: 80 },
]

export default function PatientAdmissionsReport() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/reports">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Patient Admissions Report</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button variant="outline">
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-4 md:flex-row md:items-center">
        <div className="flex-1">
          <p className="text-muted-foreground">
            This report shows the monthly patient admission and discharge statistics for the current year.
          </p>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="2023">
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
              <SelectItem value="2021">2021</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all">
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="cardiology">Cardiology</SelectItem>
              <SelectItem value="neurology">Neurology</SelectItem>
              <SelectItem value="orthopedics">Orthopedics</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Monthly Patient Admissions vs Discharges</CardTitle>
          <CardDescription>January - December 2023</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="admissions" fill="#3b82f6" name="Admissions" />
                <Bar dataKey="discharges" fill="#10b981" name="Discharges" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Summary Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Admissions:</span>
                <span className="font-medium">771</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Discharges:</span>
                <span className="font-medium">689</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Average Monthly Admissions:</span>
                <span className="font-medium">64.25</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Average Monthly Discharges:</span>
                <span className="font-medium">57.42</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Highest Admission Month:</span>
                <span className="font-medium">December (85)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Lowest Admission Month:</span>
                <span className="font-medium">July (40)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Trends and Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm">
                <span className="font-medium">Seasonal Patterns:</span> Admissions tend to increase during winter months
                (December-March) and decrease during summer (June-August).
              </p>
              <p className="text-sm">
                <span className="font-medium">Growth Rate:</span> Overall admissions have increased by 12% compared to
                the previous year.
              </p>
              <p className="text-sm">
                <span className="font-medium">Department Analysis:</span> Cardiology and Pulmonology departments saw the
                highest increase in admissions.
              </p>
              <p className="text-sm">
                <span className="font-medium">Length of Stay:</span> The average length of stay has decreased from 5.2
                days to 4.8 days.
              </p>
              <p className="text-sm">
                <span className="font-medium">Readmission Rate:</span> The 30-day readmission rate is 8.3%, which is
                below the national average of 9.7%.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
