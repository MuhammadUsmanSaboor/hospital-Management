import { Suspense } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { ReportsList } from "@/components/reports/reports-list"
import { Skeleton } from "@/components/ui/skeleton"

function ReportsSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} className="h-[200px] w-full" />
      ))}
    </div>
  )
}

export default function ReportsPage() {
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Reports</h1>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Generate New Report
        </Button>
      </div>

      <Suspense fallback={<ReportsSkeleton />}>
        <ReportsList />
      </Suspense>
    </div>
  )
}
